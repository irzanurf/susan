<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require 'vendor/autoload.php';
use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfReader;
use PhpOffice\PhpWord\Element\Table;
use PhpOffice\PhpWord\TemplateProcessor;
use PhpOffice\PhpWord\PhpWord;
function insertAtPosition($string, $insert, $position) {
    return implode($insert, str_split($string, $position));
}

function penyebut($nilai) {
    $nilai = abs($nilai);
    $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    $temp = "";
    if ($nilai < 12) {
        $temp = " ". $huruf[$nilai];
    } else if ($nilai <20) {
        $temp = penyebut($nilai - 10). " belas";
    } else if ($nilai < 100) {
        $temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
    } else if ($nilai < 200) {
        $temp = " seratus" . penyebut($nilai - 100);
    } else if ($nilai < 1000) {
        $temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
    } else if ($nilai < 2000) {
        $temp = " seribu" . penyebut($nilai - 1000);
    } else if ($nilai < 1000000) {
        $temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
    } else if ($nilai < 1000000000) {
        $temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
    } else if ($nilai < 1000000000000) {
        $temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
    } else if ($nilai < 1000000000000000) {
        $temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
    }     
    return $temp;
}

function terbilang($nilai) {
    if($nilai<0) {
        $hasil = "minus ". trim(penyebut($nilai));
    } else {
        $hasil = trim(penyebut($nilai));
    }     		
    return $hasil;
}
class Common extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        //load model admin
        $this->load->model('M_Login');
        $current_user=$this->M_Login->is_role();
        //cek session dan level user
        if(empty($this->M_Login->is_role())){
            redirect("welcome/");
        }
        $this->load->helper('file');
        $this->load->model('M_Akun');
        $this->load->model('M_SK');
    }

    public function detail(){
        $head['username'] = $this->session->userdata('username');
        $head['role'] = $this->session->userdata('role');
        $head['nama'] = $this->session->userdata('nama');
        $id = $this->input->post('id');
        if (empty($id)){
            redirect(base_url('/'));
        };
        $sent = ["tb_sk.id"=>$id];
        $id_sk = ["id_sk"=>$id];
        $data['menimbang'] = $this->M_SK->get_menimbang($id_sk)->result();
        $data['mengingat'] = $this->M_SK->get_mengingat($id_sk)->result();
        $data['menetapkan'] = $this->M_SK->get_menetapkan($id_sk)->result();
        $data['sk'] = $this->M_SK->get_SK($sent)->row();
        $dep = $this->M_SK->get_note_dep($id_sk)->row();
        if (!empty($dep)){
            $data['dep']=$dep;
        };
        $kadep = $this->M_SK->get_note_kadep($id_sk)->row();
        if (!empty($kadep)){
            $data['kadep']=$kadep;
        };
        $verifikator = $this->M_SK->get_note_verifikator($id_sk)->row();
        if (!empty($verifikator)){
            $data['verifikator']=$verifikator;
        };
        $supervisor = $this->M_SK->get_note_supervisor($id_sk)->row();
        if (!empty($supervisor)){
            $data['supervisor']=$supervisor;
        };
        $supervisor2 = $this->M_SK->get_note_supervisor2($id_sk)->row();
        if (!empty($supervisor2)){
            $data['supervisor2']=$supervisor2;
        };
        $manager = $this->M_SK->get_note_manager($id_sk)->row();
        if (!empty($manager)){
            $data['manager']=$manager;
        };
        $wadek1 = $this->M_SK->get_note_wadek1($id_sk)->row();
        if (!empty($wadek1)){
            $data['wadek1']=$wadek1;
        };
        $wadek2 = $this->M_SK->get_note_wadek2($id_sk)->row();
        if (!empty($wadek2)){
            $data['wadek2']=$wadek2;
        };
        $dekan = $this->M_SK->get_note_dekan($id_sk)->row();
        if (!empty($dekan)){
            $data['dekan']=$dekan;
            $data['catatan']=$dekan->catatan;
        };
        $log_dep = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>0))->result();
        $log_kadep = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>1))->result();
        $log_ver = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>2))->result();
        $log_sup = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>3))->result();
        $log_sup2 = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>4))->result();
        $log_man = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>5))->result();
        $log_wad1 = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>6))->result();
        $log_wad2 = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>7))->result();
        $log_dekan = $this->M_SK->get_log(array("id_sk"=>$id, "user"=>8))->result();
        $log_finish = $this->M_SK->get_log(array("id_sk"=>$id, "next_user"=>9))->result();
        $data['log_finish'] = $log_finish;
        $data['log_departemen'] = $log_dep;
        $data['log_kadep'] = $log_kadep;
        $data['log_verifikator'] = $log_ver;
        $data['log_supervisor'] = $log_sup;
        $data['log_supervisor2'] = $log_sup2;
        $data['log_manager'] = $log_man;
        $data['log_wadek1'] = $log_wad1;
        $data['log_wadek2'] = $log_wad2;
        $data['log_dekan'] = $log_dekan;
        $head['cek'] = "cek";
        $this->load->view('layout/header', $head);
        $this->load->view('detail', $data);
        $this->load->view('layout/footer');
    }
    
    public function create_sk($id){
        // $this->load->library('htmlpdf');
        \PhpOffice\PhpWord\Settings::setPdfRendererPath('vendor/dompdf/dompdf');
        \PhpOffice\PhpWord\Settings::setPdfRendererName('DomPDF');

        // $id = $this->input->post('id');
        $sent = ["tb_sk.id"=>$id];
        $id_sk = ["id_sk"=>$id];
        $menimbang = $this->M_SK->get_menimbang($id_sk)->result();
        $mengingat = $this->M_SK->get_mengingat($id_sk)->result();
        $menetapkan = $this->M_SK->get_menetapkan($id_sk)->result();
        $sk = $this->M_SK->get_SK($sent)->row();
        $judul = str_replace('&', '&amp;', strtoupper($sk->judul));
        $no_sk = str_replace('&', '&amp;', "$sk->no_sk");
        $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('assets/template/template.docx');
            $templateProcessor->setValues([
                'no_sk' => "$no_sk",
                'judul' => "PENYELENGGARAAN KEGIATAN ".strip_tags($judul),
                'departemen' => ucwords($sk->departemen)
                ]);
                $num_menimbang = "a";
                $num_mengingat = "1";
                $num_menetapkan = "1";
                $count_a = count($menimbang);
                $templateProcessor->cloneRow('a', $count_a);
                for($i=1; $i<=$count_a; $i++){
                    $val_menimbang = str_replace('&', '&amp;', strip_tags($menimbang[$i-1]->menimbang));
                    $set_menimbang = "$num_menimbang.";
                    $templateProcessor->setValue('a#'."$i",  "$set_menimbang", 1);
                    $templateProcessor->setValue('menimbang#'."$i",  "$val_menimbang", 1);
                    $num_menimbang++;
                };

                $count_b = count($mengingat);
                $templateProcessor->cloneRow('b', $count_b);
                for($j=1; $j<=$count_b; $j++){
                    $val_mengingat = str_replace('&', '&amp;', strip_tags($mengingat[$j-1]->mengingat));
                    $set_mengingat = "$num_mengingat.";
                    $templateProcessor->setValue('b#'."$j",  "$set_mengingat", 1);
                    $templateProcessor->setValue('mengingat#'."$j",  "$val_mengingat", 1);
                    $num_mengingat++;
                };

                $count_c = count($menetapkan);
                $templateProcessor->cloneRow('c', $count_c);
                for($k=1; $k<=$count_c; $k++){
                    $val_menetapkan = str_replace('&', '&amp;', strip_tags($menetapkan[$k-1]->menetapkan));
                    $num_new = strtoupper(terbilang($num_menetapkan));
                    $set_menetapkan = "KE$num_new";
                    $templateProcessor->setValue('c#'."$k",  "$set_menetapkan", 1);
                    $templateProcessor->setValue('menetapkan#'."$k",  "$val_menetapkan", 1);
                    $num_menetapkan++;
                };

                $title = MD5("$id");
                $templateProcessor->saveAs('assets/file/'."$title".'.docx');
                $datafile = [
                    "file"=>"$title".".docx",];
                    // $this->M_Pengaduan->update_pengaduan($datafile,$id);
                $cond = ['id'=>$id];
                $this->M_SK->update_pengajuan($datafile, $cond);
                $this->session->set_flashdata('info', '<div class="alert alert-success" style="margin-top: 3px">
                <div class="header"><b><i class="fa fa-exclamation-circle"></i> SUCCESS</b> Proses berhasil, silahkan pilih "detail" untuk melihat progres</div></div>');
                redirect(base_url('/'));
    }

    public function download_sk(){
        // $this->load->library('htmlpdf');
        \PhpOffice\PhpWord\Settings::setPdfRendererPath('vendor/dompdf/dompdf');
        \PhpOffice\PhpWord\Settings::setPdfRendererName('DomPDF');

        $id = $this->input->post('id');
        $sent = ["tb_sk.id"=>$id];
        $id_sk = ["id_sk"=>$id];
        $menimbang = $this->M_SK->get_menimbang($id_sk)->result();
        $mengingat = $this->M_SK->get_mengingat($id_sk)->result();
        $menetapkan = $this->M_SK->get_menetapkan($id_sk)->result();
        $sk = $this->M_SK->get_SK($sent)->row();
        $judul = str_replace('&', '&amp;', strtoupper($sk->judul));
        $no_sk = str_replace('&', '&amp;', "$sk->no_sk");
        $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('assets/template/template.docx');
            $templateProcessor->setValues([
                'no_sk' => "$no_sk",
                'judul' => strip_tags($judul),
                'departemen' => ucwords($sk->departemen)
                ]);
                $num_menimbang = "a";
                $num_mengingat = "1";
                $num_menetapkan = "1";
                $count_a = count($menimbang);
                $templateProcessor->cloneRow('a', $count_a);
                for($i=1; $i<=$count_a; $i++){
                    $val_menimbang = str_replace('&', '&amp;', strip_tags($menimbang[$i-1]->menimbang));
                    $set_menimbang = "$num_menimbang.";
                    $templateProcessor->setValue('a#'."$i",  "$set_menimbang", 1);
                    $templateProcessor->setValue('menimbang#'."$i",  "$val_menimbang", 1);
                    $num_menimbang++;
                };

                $count_b = count($mengingat);
                $templateProcessor->cloneRow('b', $count_b);
                for($j=1; $j<=$count_b; $j++){
                    $val_mengingat = str_replace('&', '&amp;', strip_tags($mengingat[$j-1]->mengingat));
                    $set_mengingat = "$num_mengingat.";
                    $templateProcessor->setValue('b#'."$j",  "$set_mengingat", 1);
                    $templateProcessor->setValue('mengingat#'."$j",  "$val_mengingat", 1);
                    $num_mengingat++;
                };

                $count_c = count($menetapkan);
                $templateProcessor->cloneRow('c', $count_c);
                for($k=1; $k<=$count_c; $k++){
                    $val_menetapkan = str_replace('&', '&amp;', strip_tags($menetapkan[$k-1]->menetapkan));
                    $num_new = strtoupper(terbilang($num_menetapkan));
                    $set_menetapkan = "KE$num_new";
                    $templateProcessor->setValue('c#'."$k",  "$set_menetapkan", 1);
                    $templateProcessor->setValue('menetapkan#'."$k",  "$val_menetapkan", 1);
                    $num_menetapkan++;
                };

                $title = MD5("$judul"."$id");
                ob_clean();
                header("Content-Disposition: attachment; filename=$title.docx");
        
                $templateProcessor->saveAs('php://output');
                
                exit;
    }
}