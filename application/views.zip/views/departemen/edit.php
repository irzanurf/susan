<div class="container-fluid">
    <div class="chit-chat-layer1">
        <!-- Progress Bar -->
        <?php $this->load->view('progress_bar') ?>
        <!-- End Progress Bar -->
        <div class="col-md-3 chit-chat-layer1">
            <div class="panel-primary">
                <div class="row" style="background-color:#337AB7; padding:15px; color: white">
                    <div style="width: 20%; float:left">
                        <i style="font-size: 55px;" class="fa fa-clock-o"></i>
                    </div>
                    <div style="width: 80%; float:right">
                        <?= $sk->departemen ?><span style="text-align: right; font-size:15px"><br>
                            <?php   if (empty($dekan->tgl)){
                                        $now = date("Y-m-d");
                                        }
                                        else {
                                        $now = $dekan->tgl;
                                        }
                                        $tgl1 = new DateTime("$sk->tgl");
                                        $tgl2 = new DateTime("$now");
                                        $jarak = $tgl2->diff($tgl1)->days + 1; ?>
                            <span style="font-size:10px">
                                Rentang waktu pengajuan <b style="font-size:12px"><?= $jarak ?>
                                    hari</b><br>sampai
                                finish
                                draft
                            </span>
                    </div>
                </div>
                <?php $this->load->view('catatan') ?>
            </div>
        </div>
        <div class="col-md-9 chit-chat-layer1">
            <div class="work-progres" style="background-color: #eef0fd">
                <div class="row" style="margin-left: 5px; margin-right: 5px;">
                    <form method="post" enctype="multipart/form-data"
                        action="<?php echo base_url()?>departemen/update_pengajuan">
                        <h2 style="text-align: center;">Edit SK Dekan</h2>
                        <hr>
                        <input type="hidden" name="id" value="<?=$id?>" />
                        <label style="font-size: 20px">Judul</label><br>
                        <textarea rows="5" name="judul" type="text" placeholder="Write here..."
                            class="form-control"><?= $sk->judul ?></textarea>
                        <hr>

                        <!-- Menimbang Input -->
                        <div class="form-group">
                            <label style="font-size: 20px">Menimbang</label><br>
                            <label style="color:red; font-size:12px;">*Isikan tanpa menggunakan nomor urut</label>
                            <div class="input-group-btn">
                                <button class="btn btn-success add-menimbang" type="button"><i class="fa fa-plus"></i>
                                    Add</button>
                            </div>
                            <div class="control-group after-add-menimbang">
                                <?php foreach($menimbang as $v) { ?>
                                <div class="control-group input-group">
                                    <textarea rows="7" name="menimbang[]" id="<?=$v->id?>editor-menimbang"
                                        class="form-control"><?= $v->menimbang ?></textarea><br>
                                    <div class="input-group-btn">
                                        <button class="btn-sm btn-danger remove-menimbang1"
                                            onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?');"
                                            type="button"><i class="fa fa-remove"></i> <br>Remove</button>
                                    </div>
                                </div>
                                <script>
                                // CKEDITOR.replace("<?=$v->id?>editor-menimbang");
                                </script>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="copy-menimbang hide">
                            <div class="control-group input-group">
                                <textarea rows="7" name="menimbang[]" id="editor-copy-menimbang" type="text"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                                <div class="input-group-btn">
                                    <button class="btn-sm btn-danger remove-menimbang"
                                        onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?');" type="button"><i
                                            class="fa fa-remove"></i> <br>Remove</button>
                                </div>
                            </div>
                        </div>

                        <!-- Mengingat input -->
                        <div class="form-group">
                            <label style="font-size: 20px">Mengingat</label><br>
                            <label style="color:red; font-size:12px;">*Isikan tanpa menggunakan nomor urut</label>
                            <div class="input-group-btn">
                                <button class="btn btn-success add-mengingat" type="button"><i class="fa fa-plus"></i>
                                    Add</button>
                            </div>
                            <div class="after-add-mengingat">
                                <?php foreach($mengingat as $v) { ?>
                                <div class="control-group input-group">
                                    <textarea rows="7" name="mengingat[]" id="<?=$v->id?>editor-mengingat"
                                        class="form-control"><?= $v->mengingat ?></textarea><br>
                                    <div class="input-group-btn">
                                        <button class="btn-sm btn-danger remove-mengingat1"
                                            onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?');"
                                            type="button"><i class="fa fa-remove"></i> <br>Remove</button>
                                    </div>
                                </div>
                                <script>
                                // CKEDITOR.replace("<?=$v->id?>editor-mengingat");
                                </script>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="copy-mengingat hide">
                            <div class="control-group input-group">
                                <textarea rows="7" name="mengingat[]" id="editor-copy-mengingat" type="text"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                                <div class="input-group-btn">
                                    <button class="btn-sm btn-danger remove-mengingat"
                                        onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?');" type="button"><i
                                            class="fa fa-remove"></i> <br>Remove</button>
                                </div>
                            </div>
                        </div>

                        <!-- Menetapkan input -->
                        <div class="form-group">
                            <label style="font-size: 20px">Menetapkan</label><br>
                            <label style="color:red; font-size:12px;">*Isikan tanpa menggunakan nomor urut</label>
                            <div class="input-group-btn">
                                <button class="btn btn-success add-menetapkan" type="button"><i class="fa fa-plus"></i>
                                    Add</button>
                            </div>
                            <div class="control-group after-add-menetapkan">
                                <?php foreach($menetapkan as $v) { ?>
                                <div class="control-group input-group">
                                    <textarea rows="7" name="menetapkan[]" id="<?=$v->id?>editor-menetapkan"
                                        class="form-control"><?= $v->menetapkan ?></textarea><br>
                                    <div class="input-group-btn">
                                        <button class="btn-sm btn-danger remove-menetapkan1"
                                            onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?');"
                                            type="button"><i class="fa fa-remove"></i> <br>Remove</button>
                                    </div>
                                </div>
                                <script>
                                // CKEDITOR.replace("<?=$v->id?>editor-menetapkan");
                                </script>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="copy-menetapkan hide">
                            <div class="control-group input-group">
                                <textarea rows="7" name="menetapkan[]" id="editor-copy-menetapkan"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                                <div class="input-group-btn">
                                    <button class="btn-sm btn-danger remove-menetapkan"
                                        onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?');" type="button"><i
                                            class="fa fa-remove"></i> <br>Remove</button>
                                </div>
                            </div>
                        </div>

                        <!-- Lampiran -->
                        <div class="form-group">
                            <label style="font-size: 20px">File Lampiran</label><br>
                            <?php if (!empty($sk->lamp)) : ?>
                            <div class="form-group">
                                <button method="post"
                                    onclick=" window.open('<?= base_url('assets/lampiran');?>/<?=$sk->lamp?>', '_blank'); return false;"
                                    class="btn btn-primary-outline"><img src="<?= base_url('assets/attach.png');?>"
                                        alt="attach" width="50" height="50" /></button>
                            </div>

                            <?php else : ?>

                            <?php endif; ?>
                            <input type="file" name="file"> <br>
                            <label style="color:red; font-size:12px;">maks 10mb</label>
                        </div><br>
                        <div class="form-group">
                            <label style="font-size: 20px">Catatan dari departemen</label><br>
                            <div>
                                <?php if(empty($dep)){ ?>
                                <textarea rows="5" name="catatan" type="text" placeholder="Write here..."
                                    class="form-control"></textarea><br>
                                <?php } else { ?>
                                <textarea rows="5" name="catatan" type="text" placeholder="Write here..."
                                    class="form-control"><?=$dep->catatan?></textarea><br>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" name="status" class="btn btn-info" value="draft">
                                Simpan Draft
                            </button>
                            <button type="submit" name="status" value="0"
                                onclick="return confirm('Apakah Anda yakin dengan pilihan Anda?');"
                                class="btn btn-success">
                                Simpan & Kirim Draft
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"> </div>

<script type="text/javascript">
$(document).ready(function() {
    $(".add-mengingat").click(function() {
        var html = $(".copy-mengingat").html();
        $(".after-add-mengingat").after(html);
        // CKEDITOR.replace('editor-copy-mengingat');
    });
    $("body").on("click", ".remove-mengingat1", function() {
        $(this).closest(".control-group").remove();
    });
    $("body").on("click", ".remove-mengingat", function() {
        $(this).closest(".control-group").remove();
    });
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    $(".add-menimbang").click(function() {
        var html = $(".copy-menimbang").html();
        $(".after-add-menimbang").after(html);
        // // CKEDITOR.replace('editor-copy-menimbang');
    });
    $("body").on("click", ".remove-menimbang1", function() {
        $(this).closest(".control-group").remove();
    });
    $("body").on("click", ".remove-menimbang", function() {
        $(this).closest(".control-group").remove();
    });
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    $(".add-menetapkan").click(function() {
        var html = $(".copy-menetapkan").html();
        $(".after-add-menetapkan").after(html);
        // // CKEDITOR.replace('editor-copy-menetapkan');
    });
    $("body").on("click", ".remove-menetapkan1", function() {
        $(this).closest(".control-group").remove();
    });
    $("body").on("click", ".remove-menetapkan", function() {
        $(this).closest(".control-group").remove();
    });
});
</script>