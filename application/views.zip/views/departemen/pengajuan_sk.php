<div class="container-fluid">
    <div class="chit-chat-layer1">
        <div class="col-md-12 chit-chat-layer1">
            <div class="work-progres" style="background-color: #eef0fd">
                <div class="row" style="margin-left: 5px; margin-right: 5px;">
                    <form method="post" enctype="multipart/form-data"
                        action="<?php echo base_url()?>departemen/insert_pengajuan">
                        <h2 style="text-align: center;">Pengajuan SK Dekan</h2>
                        <hr>
                        <label style="font-size: 20px">Judul</label><label style="color:red; font-size:12px;">
                            (*Wajib
                            diisi)</label><br>
                        <textarea rows="5" name="judul" id="judul" type="text" placeholder="Write here..."
                            class="form-control" required=""></textarea>
                        <hr>
                        <div class="form-group">
                            <label style="font-size: 20px">Menimbang</label><br>
                            <label style="color:red; font-size:12px;">*Isikan tanpa menggunakan nomor urut</label>
                            <div class="input-group-btn">
                                <button class="btn btn-success add-menimbang" type="button"><i class="fa fa-plus"></i>
                                    Add</button>
                            </div>
                            <div class="control-group after-add-menimbang">
                                <textarea rows="7" name="menimbang[]" id="editor-menimbang" type="text"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                            </div>
                            <div class="before-add-menimbang">
                            </div>
                            <div class="copy-menimbang hide">
                                <div class="control-group input-group">
                                    <textarea rows="7" name="menimbang[]" id="editor-copy-menimbang" type="text"
                                        placeholder="Write here..." class="form-control"></textarea><br>
                                    <div class="input-group-btn">
                                        <button class="btn-sm btn-danger remove-menimbang" type="button"><i
                                                class="fa fa-remove"></i> <br>Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label style="font-size: 20px">Mengingat</label><br>
                            <label style="color:red; font-size:12px;">*Isikan tanpa menggunakan nomor urut</label>
                            <div class="input-group-btn">
                                <button class="btn btn-success add-mengingat" type="button"><i class="fa fa-plus"></i>
                                    Add</button>
                            </div>
                            <div class="control-group after-add-mengingat">
                                <textarea rows="7" name="mengingat[]" id="editor-mengingat" type="text"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                            </div>
                            <div class="before-add-mengingat">
                            </div>
                        </div>
                        <div class="copy-mengingat hide">
                            <div class="control-group input-group">
                                <textarea rows="7" name="mengingat[]" id="editor-copy-mengingat" type="text"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                                <div class="input-group-btn">
                                    <button class="btn-sm btn-danger remove-mengingat" type="button"><i
                                            class="fa fa-remove"></i> <br>Remove</button>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label style="font-size: 20px">Menetapkan</label><br>
                            <label style="color:red; font-size:12px;">*Isikan tanpa menggunakan nomor urut</label>
                            <div class="input-group-btn">
                                <button class="btn btn-success add-menetapkan" type="button"><i class="fa fa-plus"></i>
                                    Add</button>
                            </div>
                            <div class="control-group after-add-menetapkan">
                                <textarea rows="7" name="menetapkan[]" id="editor-menetapkan" type="text"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                            </div>
                            <div class="before-add-menetapkan">
                            </div>
                        </div>
                        <div class="copy-menetapkan hide">
                            <div class="control-group input-group">
                                <textarea rows="7" name="menetapkan[]" id="editor-copy-menetapkan"
                                    placeholder="Write here..." class="form-control"></textarea><br>
                                <div class="input-group-btn">
                                    <button class="btn-sm btn-danger remove-menetapkan" type="button"><i
                                            class="fa fa-remove"></i> <br>Remove</button>
                                </div>
                            </div>
                        </div><br>
                        <!-- Lampiran -->
                        <div class="form-group">
                            <label style="font-size: 20px">File Lampiran</label><br>
                            <input type="file" name="file"> <br>
                            <label style="color:red; font-size:12px;">maks 10mb</label>
                        </div><br>
                        <div class="form-group">
                            <label style="font-size: 20px">Catatan dari departemen</label><br>
                            <div class="control-group after-add-mengingat">
                                <textarea rows="5" name="catatan" type="text" placeholder="Write here..."
                                    class="form-control"></textarea><br>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" name="status" class="btn btn-info" value="draft">
                                Simpan Draft
                            </button>
                            <button type="submit" name="status" value="0"
                                onclick="return confirm('Apakah Anda yakin dengan pilihan Anda?');"
                                class="btn btn-success">
                                Simpan & Kirim Draft
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
    var k = 0;
    $(".add-mengingat").click(function() {
        k = k + 1;
        var html = $(".copy-mengingat").html();
        $(".before-add-mengingat").before(html);
        $("#editor-copy-mengingat").attr("id", "editor-copy-mengingat" + k);
        // CKEDITOR.replace('editor-copy-mengingat' + k);
    });
    $("body").on("click", ".remove-mengingat", function() {
        $(this).parents(".control-group").remove();
    });
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    var j = 0;
    $(".add-menimbang").click(function() {
        j = j + 1;
        var html = $(".copy-menimbang").html();
        $(".before-add-menimbang").before(html);
        $("#editor-copy-menimbang").attr("id", "editor-copy-menimbang" + j);
        // CKEDITOR.replace('editor-copy-menimbang' + j);
    });
    $("body").on("click", ".remove-menimbang", function() {
        $(this).parents(".control-group").remove();
    });
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    var i = 0;
    $(".add-menetapkan").click(function() {
        i = i + 1;
        var html = $(".copy-menetapkan").html();
        $(".before-add-menetapkan").before(html);
        $("#editor-copy-menetapkan").attr("id", "editor-copy-menetapkan" + i);
        // CKEDITOR.replace('editor-copy-menetapkan' + i);
    });
    $("body").on("click", ".remove-menetapkan", function() {
        $(this).parents(".control-group").remove();
    });
});
</script>

<!-- <script>
    $("textarea").each(function(){
        CKEDITOR.replace( this );
});
</script> -->