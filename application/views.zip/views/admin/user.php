<div class="chit-chat-layer1">
    <div class="col-md-12 chit-chat-layer1">
        <div class="work-progres">
            <?php if($this->session->flashdata('info')){echo $this->session->flashdata('info');}?>
            <div class="table-responsive">
                <table id="dataTable" class="table table-hover">
                    <thead>
                        <tr>
                            <th style="text-align:center">Username</th>
                            <th style="text-align:center">Nama</th>
                            <th style="text-align:center">Departemen</th>
                            <th style="text-align:center">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>

                        </tr>
                    </tfoot>
                    <tbody>
                        <?php 
                                   foreach($view as $v){
                              ?>
                        <tr>
                            <td><?= $v->username ?></td>
                            <td><?= $v->nama ?></td>
                            <td><?php if(!empty($v->departemen)) {?>
                                <?= $v->departemen ?>
                                <?php } ?></td>
                            <td style="text-align:center; width:15%">
                                <form style="display:inline-block;" method="post"
                                    action="<?= base_url('admin/akun') ?>">
                                    <input type='hidden' name="username" value="<?= $v->username ?>">
                                    <button type="submit" class="btn btn-primary-outline" data-toggle="tooltip"
                                        data-placement="top" title="Akun">
                                        <i class="fa fa-user" style="font-size: 20px; color: green"> </i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="clearfix"> </div>
</div>